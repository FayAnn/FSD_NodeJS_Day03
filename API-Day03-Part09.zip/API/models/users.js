const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/Weights',
  {
    useNewUrlParser: true,
    useUnifiedTopology: true
  }
);
//
const wSchema = new mongoose.Schema({
  empName: String,
  empPass: String,
  created: {type: Date, default: Date.now }
},{
	collection:'EmployeeUsers'
});
module.exports = mongoose.model('Users', wSchema);
